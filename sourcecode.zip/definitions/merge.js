// Merging static files
// Only CSS and JavaScript

// CSS
F.merge('/css/manager.css', '/css/bootstrap.min.css', '/css/ui.css#manager', '/css/manager.css');

// JavaScript
F.merge('/js/manager.js', '/js/jctajr.min.js', '/js/ui.js#manager', '/js/manager.js');